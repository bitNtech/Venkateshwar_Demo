# AICA backend: VAD, turn-taking and perceived-latency pass

Branch `backend`, based on commit `7602d3a` ("Update conversation").
Date: 2026-09-26.

## What is in this bundle

| Path | What it is |
|---|---|
| `vad-asr-enhancements.patch` | Every change as one git patch. Apply on `7602d3a` with `git apply vad-asr-enhancements.patch`. |
| `files/` | The same 18 files as full copies, in repo layout, for reading or copying over by hand. |
| `ENHANCEMENTS_LOG.md` | This file. |

**Not included, on purpose:** `.env` (it holds an HF token), `.venv`, `NeMo_ai4bharat/` and `call_events.db`.

**What was left alone:** the ASR model loading and decoding, LLM prompt content, TTS engine selection, `telephony.py` and `persistence.py` are all unchanged. The only ASR-adjacent addition is a pitch estimate that runs next to the ASR decode, described in section 2b. The one small LLM-path touch is also in section 2b.

## Summary

| # | Item | Status |
|---|---|---|
| 1 | Stale `clause_chunker.py` docstring | Fixed (comment only) |
| 2 | Filler / backchannel system | Built, tested, on by default, one-flag off-switch |
| 2b | சார்/மேடம் from caller voice pitch | Built; estimator replaced with YIN after a real-user bug (see 2b). On by default, one-flag off-switch |
| 3 | Noise-floor instrumentation for headphone calls | Built, off by default. **No real call has been measured yet.** |
| 4 | Headphone-mode barge-in | **Not done.** It depends on item 3's measurement. |
| 5 | Latency review of the hot path | Done, read-only. Findings are listed below and none are fixed. |
| 6 | **Simple voice test page** at `/lab` | Built. See "How to test" just below. |

**No measured VAD or barge-in constant was changed.** That covers `vad_onset_min_rms`, `vad_onset_snr`, `vad_noise_ema`, all `barge_in_*` counts and the endpoint frames.

**Tests:**
- Baseline before any change: 60/60 across `test_vad`, `test_barge_in`, `test_clause_chunker` and `test_main`.
- After all changes: **271/271 for the full `backend/` suite**, including 26 new tests.
- The patch was also applied to a clean checkout of `7602d3a`, and the suite passed there.

## How to test: the voice test page (`/lab`)

Start the server as usual (`./run.sh`) and open **http://localhost:8000/lab**. If `AUDIO_WS_AUTH_TOKEN` is set, use `/lab?token=...`.

- **Over SSH:** tunnel the port first with `ssh -L 8000:127.0.0.1:8000 user@host`, then open the `localhost` address. Browsers only allow the microphone on `https` or `localhost` pages, so `http://<ip>:8000` will not get mic access.

**Steps:**
1. Press **Start** and allow the microphone.
2. Wait for the greeting to finish, then speak Tamil. Headphones work best.

**What the page shows, and nothing else:**
- **Status:** listening, you're speaking, or agent speaking, with a mic level bar.
- **Speech-to-text:** whether ASR is loaded.
- **Addressed as:** சார், மேடம், or "not decided yet".
- **The conversation:**
  - your words live as you speak, then the final transcript with how long it took after you stopped;
  - the filler, with its timing;
  - the agent's reply, or on a machine with no LLM, a clear "No reply: the LLM is not running" line.

**For the noise-floor measurement (item 3):** use `VAD_DIAGNOSTICS_MS` and `noise_floor_report.py`, not this page.

## Verified against a live server

The server ran with the real TEN VAD, **the real IndicConformer ASR (CPU)**, real edge TTS and the real FastAPI app. There was no LLM on the test machine, so replies end in "Connection error", as expected. The caller was a real Tamil male neural voice (`ta-IN-ValluvarNeural`) played in real time, with room noise and pauses.

| Check | Result |
|---|---|
| Filler bank warm-up at startup | 5/5 phrases cached, all in the background |
| `/lab` served | 200 |
| Two spoken sentences with a pause | exactly 2 turns; onset ~70ms after speech began; both closed on silence |
| Noise floor, no AGC | flat (41.5 → 39.8) across the run |
| Typed turn with the LLM unreachable, sent after the greeting finished | filler "சரி…" at 0.36s, `agent_speaking_end` at 1.18s, error at 1.19s |
| Typed turn sent while the greeting was still audible | no filler, correctly: fillers never queue behind playing audio |
| Test page script | every event handler runs cleanly on the live event sequence (Node, stubbed DOM) |
| ASR, sentence 1 (3.9s) | said "வணக்கம், எனக்கு Cardiology-ல ஒரு appointment வேணும்." → heard "வணக்கம் எனக்கு கார்டியோலஜில ஒரு appointment வேணும்"; final decode 0.53s on CPU |
| ASR, sentence 2 (2.0s) | said "நாளைக்கு காலையில கிடைக்குமா?" → heard it exactly; final decode 0.30s on CPU |
| Interim transcripts | streamed about every 0.5s while speaking; interim decode 0.13–0.19s |
| Transcript after caller stops (end to end over the socket) | 0.65s and 0.36s (CPU; a GPU will be faster) |
| சார்/மேடம் | சார், decided on the caller's first sentence (male voice) |
| Filler on a spoken turn | "ம்ம்…" 0.36s after the transcript; the next turn got "சரி சார்…", using the decided honorific |

**Bug found by this live run, and fixed:** when a turn failed (for example, the LLM unreachable) after a filler had announced `agent_speaking_start`, no `agent_speaking_end` was sent, so the "agent speaking" indicator stayed on. A failure *before* the threshold also left the filler timer running, so it could play after the error. Now both are handled, and two regression tests cover them.

**Tested by a real person:** a male tester, speaking Tamil through a Realtek headset over an SSH tunnel.
- **Worked:** speech detection and transcripts.
- **Failed:** he was addressed as **மேடம்**. That was a real bug, fixed in 2b below. After the fix, the same scenario replayed through a simulated small-mic filter gives `median 150 Hz -> சார்`.

**Not verified live:** the LLM → TTS reply (no LLM on the test machine). Since the fix, the honorific has only been re-checked on neural voices, not re-tested by the person who found the bug.

---

## 1. Stale docstring (`clause_chunker.py`)

**The problem:** the docstring said the chunker receives the whole LLM reply in a single `feed()` call. That was no longer true. `conversation.stream_utterance()` calls `feed()` once per streamed text delta.

**The fix:** the docstring now describes the real flow:
- `feed()` is called per delta, and each clause it releases goes to TTS immediately.
- `flush()` is called once the stream completes, to release the last clause.
- Scripted text (the greeting and the recovery lines) goes through `split_reply_into_clauses()`.

No code changed.

## 2. Fillers: "சரி…", "ம்ம்…" while the reply is coming

### Why
The first clause of a turn is the only one whose latency isn't hidden behind audio that is already playing. The caller hears silence for all of it: the ASR decode, the model's time to first clause (median 2.7s per `LLM_TEST_RESULTS.txt`), then one TTS round-trip.

### What it does (`backend/filler.py`, wired in `main.py`)
- **Trigger:** if no real audio is ready within `FILLER_THRESHOLD_MS` (default 350) of a caller turn reaching the agent, one short acknowledgement plays.
- **Cut-off:** the filler is cut with a 30ms client-side fade the moment the first real clause's **audio** is ready. The brief said to cut on the first clause's text, but the audio arrives a full synthesis (about 1s) later, so cutting on text would leave that second silent. This is a one-line change if you want the text trigger back.
- **Barge-in:** the filler runs inside the same `speak()` task that barge-in already cancels, so it uses the existing cancellation path and never gets a second one.
- **When it never plays:** on the scripted greeting, on non-Tamil calls, when TTS isn't ready, or while earlier agent audio is still audible. It won't queue behind that audio.
- **Rotation:** the same phrase never plays twice in a row.

### Measured, and why the audio is pre-synthesised
Edge TTS (`ta-IN-PallaviNeural`) on the candidate phrases:

| Phrase | Synthesis time | Audio length |
|---|---|---|
| சரி… | 1.38s | 0.58s |
| ம்ம்… | 0.96s | 0.40s |
| சரிங்க… | 1.22s | 0.72s |
| சரி சார்… | 1.20s | 0.92s |
| சரி மேடம்… | 1.32s | 1.02s |
| ம்ம், சரி சார். | 1.20s | 1.42s (dropped: too long, gets cut mid-word) |

- **Synthesis time:** 1.0–1.5s. A filler synthesised on demand would arrive *after* the reply it was meant to cover.
- **Therefore:** the phrase bank is synthesised **once per server process**, in the background at startup. A phrase that isn't cached yet is skipped; nothing is synthesised on the hot path.

### Phrase bank and register
- **With no honorific decided:** சரி…, ம்ம்…, சரிங்க…
- **Once decided:** சரி சார்… or சரி மேடம்… joins the rotation.
- **Acknowledgement only:** `golden/runtime_core.txt` forbids narrating a lookup ("ஒரு நிமிஷம் சார், system-ல check பண்றேன்"), and "ஆமாம்" would pre-agree with whatever the reply says.
- **Tamil only:** `caller_is_speaking_english()` exists but was deliberately left unwired, because English mirroring measured worse. So fillers stay in the agent's register.

### Echo safety
- **Not part of the turn:** filler text never enters `recent_agent_text`, the conversation history, or the repeat breaker.
- **`barge_in.is_probably_self_echo()` has a new optional `filler_text` argument.** When it is given, a transcript made only of the filler's words counts as echo. `main.py` passes it only for an utterance that **began while a filler was audible**, so the agent can't answer its own "சரி".
- **Unchanged otherwise:** without `filler_text` the function behaves as before, including the "never judge a short turn as echo" rule.

### Wire protocol additions
Existing clients that ignore unknown events keep working.
- `agent_filler {text}` (server → client): the next binary frame is the filler.
- `filler_stop` (server → client): fade out and drop the filler that is still playing.
- `backend/console.html` and `legacy_test_client/audio-stream.js` both implement these two events.
- `mic_settings {settings}` (client → server): what `getUserMedia` actually applied. It is stored in the call log.
- **Check the React dashboard:** it lives outside this repo. If it doesn't ignore unknown event types, add handling there or set `FILLER_ENABLED=false`.

### Off-switch
`FILLER_ENABLED=false` in `.env`, then restart.

## 2b. சார் / மேடம் from the caller's voice (`backend/honorific.py`)

The prompt requires one honorific per call, never switched, but nothing on a browser call says who is speaking.

### How it decides
- **Pitch estimate:** YIN (de Cheveigné & Kawahara), vectorised; 13ms for an 8s utterance.
- **When it commits:** after about 1s of voiced caller speech. A median of 170 Hz or below gives சார், 185 Hz or above gives மேடம், and anything in between gives nothing.
- **Once decided:** it never changes during the call.
- **When unsure:** it stays honorific-free, which is never wrong.

### What it listens to
Only utterances that were not flagged as echo and that **started while the agent was silent**. Otherwise the agent's own female TTS voice leaking back would vote மேடம்.

### Bug found by a real tester, and fixed
- **What happened:** the first estimator (autocorrelation that preferred the shorter of two near-equal periods) addressed a **male** tester on a Realtek headset as **மேடம்**.
- **Cause, reproduced:** small mics roll off a male voice's fundamental, leaving the even harmonics dominant, so the waveform looks nearly periodic at *half* its true period. On a synthetic 115 Hz voice with its fundamental removed and odd harmonics at half strength, the old estimator read **232 Hz** (மேடம்); YIN reads **115 Hz**.
- **On real voices:** under a 4th-order high-pass at 350 Hz (a small-mic stand-in), the old estimator drifted hi-IN-Madhur from 112 to 165 Hz; YIN holds 109–110 Hz.
- **Honest limit:** if the odd harmonics are weaker still (below ~0.3), YIN reads the octave too, because the signal then genuinely is closer to periodic at the higher pitch. That is why undecided remains the default.
- **Regression test:** `test_a_male_voice_through_a_small_mic_is_not_read_an_octave_high`. The old estimator fails it.
- **Diagnosis in the field:** `main.py` now logs each utterance's pitch (a number, never audio), for example `pitch for <call>: 67 voiced frames, median 150 Hz -> சார்`. Use this to check the decision band against real callers.

### Calibration (YIN)
18 Microsoft neural voices (9 male, 9 female), Tamil from IN, MY, SG and LK plus en, hi, te, ml and kn from IN, one ~6s sentence each. Each was run clean and through a 150/250/350 Hz high-pass: **72 runs**.
- male medians: 98–170 Hz. The Tamil male voices sit high, at 142–170 Hz, which is why the male line is 170 Hz, not a textbook 155.
- female medians: 191–267 Hz.
- **67 decided correctly, 5 undecided, 0 wrong.** The undecided ones are low male voices under heavy filtering, which leave too few voiced frames in a single sentence. On a real call the detector keeps accumulating over later turns.

These are synthetic voices. Check real callers with the `pitch for` log line.

### Cost
13ms for an 8-second utterance (YIN, vectorised). It runs in its own thread alongside the ASR decode, and is only awaited after the decode finishes.

### Where the result goes
- the filler phrase bank
- one line in the per-turn facts message: `address the caller as: மேடம்`. **This is the one LLM-path touch.** It goes into the volatile tail, so the cached system-prompt prefix stays byte-identical, and a test checks that.
- the scripted "stuck model" recovery lines, where சார் is swapped for மேடம்.
- a `caller_honorific` event to the client, for visibility.

### Off-switch
`HONORIFIC_DETECTION_ENABLED=false` in `.env`. Fillers then stay honorific-free, and the LLM gets no hint.

## 3. Headphone noise-floor instrumentation

### The theory being tested
1. With headphones there is no acoustic echo, but browser AGC on a close mic can lift the level of the pauses.
2. `_update_noise_floor()` learns only from frames the VAD calls non-speech, which are exactly those pauses.
3. So the learned floor may climb over a call, raising the onset bar (floor × `VAD_ONSET_SNR`) until turns get hard to start.

### What was added
All of it is off by default; nothing changes unless it is switched on.
- **`VAD_DIAGNOSTICS_MS`** in `settings.py` (default 0, meaning off). At 500, one sample per 500ms goes to the **call log only**, never to the client. Each sample holds:
  - `t`: time into the call
  - `noise_floor` and `onset_bar`
  - `room_rms` and `p_max` (peak VAD probability)
  - `in_speech` and `agent_audible`
  - `speech_hops`
  - `onset_refusals`: frames the VAD flagged as speech that the loudness gate refused to open a turn on. This is the symptom the theory predicts.
- **`vad.py`:** a diagnostics counter (`onset_refusals`) and an `onset_bar` property, which the existing loudness check now reuses. The maths is identical, and all existing VAD tests pass.
- **Both clients** send `mic_settings`: what `getUserMedia` actually applied (echo cancellation, noise suppression, AGC, and the device label, which shows headset vs built-in mic).
  - Worth knowing: `console.html` never asks for `autoGainControl`. Chrome defaults it to on, and this confirms whether it really is.
- **Reading `onset_refusals`:** it also counts room noise that the VAD flagged but the loudness gate *correctly* rejected. The live test with white room noise logged 212 such frames with nobody talking. So it's the trend, and refusals while someone is actually trying to speak, that matter, not the raw count.
- **`python -m backend.scripts.noise_floor_report [connection_id] [--every 5]`** prints the floor over time plus a summary by thirds of the call: floor drift, speech level against the final onset bar, and refusals per third.

### How to run the measurement
1. Start the server with `VAD_DIAGNOSTICS_MS=500`.
2. Open `/console` wearing headphones. Talk normally for 2–3 minutes with natural pauses, and let the agent reply a few times.
3. Hang up and run the report.
4. Repeat once on laptop speakers for comparison.

### How to read the result
- **Theory confirmed:** the quiet-floor median rises from the first third of the call to the last, the onset bar approaches the caller's speech level, and refusals grow with it.
- **Theory ruled out:** the floor is flat and refusals don't grow.

### If confirmed
The recommended fix is a per-connection headphone vs speaker profile for echo cancellation, noise suppression and AGC in the client. Don't retune `vad_onset_snr` or `vad_onset_min_rms`: those values are shared with the room-mic case they were measured on.

**Status:** tooling built, and the report was checked on a simulated call (×2.13 drift, refusals 0 → 12 → 24). **No real call has been measured.**

## 4. Headphone-mode barge-in (not done)

The planned change is an opt-in flag that uses `barge_in_speech_frames` (240ms) instead of the 640ms audible-gate when headphones are in use, keeping the existing `__post_init__` invariant for the default. It was deliberately **not built**, because the brief made it conditional on item 3 showing it matters.

## 5. Latency review: VAD `speech_ended` → first TTS byte (read-only)

### New code in this pass
Nothing new sits synchronously on the path:

| Addition | Cost on the hot path |
|---|---|
| Filler timer | An asyncio task. Sending the filler takes the socket lock for one ~50KB frame. |
| Pitch estimate | 13ms in its own thread, running in parallel with ASR. It is awaited after the decode, by which point it has long finished. |
| `honorific.observe`, `set_caller_honorific` | Trivial list and dict operations. |
| Diagnostics | Off by default. When on, one RMS per frame plus a non-blocking queue put. |

### Existing issues noticed
None of these were fixed.

**A. Interim ASR can delay endpointing and the final decode (worth fixing).**
- `queue_segment()` awaits `asr.transcribe_partial()` inline, every 30 hops (~480ms) while the caller is speaking. `queue_segment()` is called from the audio receive loop, so VAD processing of new frames pauses during each partial decode.
- On top of that, partial and final decodes share `asr._inference_lock`. A partial decode still running when the turn ends makes the final decode wait for it.
- Together, that can add up to about one CTC decode to every turn.
- Suggested fix: run the partial as a background task, skip it if one is already in flight, and skip or cancel it once `speech_ended` fires.

**B. TTS first-clause synthesis is the biggest fixed cost after the LLM.** Edge measured 1.0–1.5s per short phrase here. Fillers hide this; they don't remove it. A local TTS engine is the real fix, and `BACKEND_COMPLETION.md` already lists that as open.

**C. Minor lock wait.** `vad_end` and `asr_start` are sent through `send_event`, which waits on `send_lock` while `speak()` holds it to send audio. This is milliseconds, not worth changing.

---

## Environment notes for whoever runs it

**Missing library:** `ten_vad`'s native library needs `libc++.so.1`. On Ubuntu:
```
sudo apt install libc++1-18 libc++abi1-18
```
Without it, the VAD fails to initialise and `test_main.py` hangs instead of failing.

**Python version:** `run.sh` requires Python 3.10 or 3.11, because NeMo doesn't support newer versions.

**Three missing NeMo packages, now added to `requirements.txt`:** on a fresh Python 3.11 venv, `nemo.collections.asr` also needed `wrapt`, `wget` and `text-unidecode`. Without them ASR load fails and `asr_ready` stays false. If your environment already works, nothing changes for you.

**Tested stack:** Python 3.11.16, torch 2.14.0 (CPU build) with the AI4Bharat NeMo fork 1.23.0rc0. The ASR model loaded and transcribed correctly on that combination. The GPU build of torch 2.14 uses CUDA 13, which needs NVIDIA driver 580 or newer.

**First ASR load downloads about 500MB** from Hugging Face and needs `HF_TOKEN` in `.env` (after accepting the model terms). Later starts load from the local cache.

**Without sudo for libc++:** copy `libc++.so.1`, `libc++abi.so.1` and `libunwind.so.1` from the `libc++1-18`, `libc++abi1-18` and `libunwind-18` `.deb` files (`apt-get download` needs no root) into a folder, and start the server with `LD_LIBRARY_PATH` pointing at it.

**`test_persistence.py` quirk:** on Linux it creates a stray empty file named `Z:\nonexistent-drive\call_events.db` in the repo root. That comes from an existing test and is safe to delete.

## Known limitations and risks

- **Fillers haven't been heard on a live call.** They're the one unmeasured system in the pipeline. Keep `FILLER_ENABLED=false` ready during the demo.
- **Filler echo could cancel a reply on speaker/room-mic setups.** In principle, a filler's echo could last past the 640ms audible-gate and cancel the agent's own reply. Real clauses have the same exposure. There's no risk with headphones.
- **"ம்ம்" transcription:** if the ASR writes it differently (for example "ம்"), its echo slips past the filler-echo check and is treated as a short caller turn.
- **Pitch is a heuristic:** elderly, hoarse or young callers can fall on the wrong side. The detector abstains inside the 170–185 Hz band, but the margins are calibrated on synthetic voices only.
- **Legacy client barge-in:** `legacy_test_client/audio-stream.js` has never handled `agent_interrupted`, so barge-in doesn't stop its playback. This is not new. `console.html` handles it correctly.

## New and changed settings

| Env var | Default | Effect |
|---|---|---|
| `FILLER_ENABLED` | `true` | Master switch for fillers |
| `FILLER_THRESHOLD_MS` | `350` | Silence allowed before a filler plays |
| `HONORIFIC_DETECTION_ENABLED` | `true` | Pitch-based சார்/மேடம் |
| `VAD_DIAGNOSTICS_MS` | `0` (off) | Noise-floor sampling interval for item 3 |

## Files

**New:**
- `backend/filler.py`
- `backend/honorific.py`
- `backend/scripts/noise_floor_report.py`
- `backend/lab.html`
- `backend/test_filler.py`
- `backend/test_honorific.py`

**Modified:**
- `requirements.txt`
- `backend/main.py`
- `backend/settings.py`
- `backend/vad.py`
- `backend/barge_in.py`
- `backend/conversation.py`
- `backend/clause_chunker.py`
- `backend/console.html`
- `legacy_test_client/audio-stream.js`
- `backend/test_main.py`
- `backend/test_vad.py`
- `backend/test_conversation.py`
